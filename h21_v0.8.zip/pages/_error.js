const Error = () => {
    return <p>에러 발생</p>
};
export default Error;