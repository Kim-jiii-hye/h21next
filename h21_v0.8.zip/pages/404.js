const NotFound = () => {
    return <p>404페이지 입니다</p>;
}
export default NotFound;