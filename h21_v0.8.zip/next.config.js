module.exports = {
  reactStrictMode: true,
  images: {
    domains: ["jsonplaceholder.typicode.com", "img.hani.co.kr", "http://mapi_h21-master.hani.co.kr"]
  },

}
