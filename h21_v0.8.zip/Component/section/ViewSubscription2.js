import React, { Component } from "react";

export default class ViewSubscription2 extends Component {
    render() {
        return (
            <div className="subscription_1">
                <div className="gudok">
                    <iframe name="iframe_gudok" src="//magazine21.hani.co.kr/h21/mypage.jsp"></iframe>

                </div>
            </div>

        )
    }
}
