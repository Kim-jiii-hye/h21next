import React, {Component} from "react";

export default class ListArticleAd1 extends Component {

    render() {
        return(
            <section id="section_sub_ad" className="sub_ad">
                <h4 className="hidden"></h4>
                <div className="visual-ad">
                    <div className="ad600">
                    </div>
                    <div className="ad320">
                    </div>
                </div>
            </section>

        )
    }
}
