import React, {Component} from "react";

export default class NavigationSeries extends Component {

    render() {
        return(
<>
</>
        )
    }
}
