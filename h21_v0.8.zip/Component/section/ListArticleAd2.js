import React, {Component} from "react";

export default class ListArticleAd2 extends Component {

    render() {
        return(
            <section id="ad-side01" className="side-ad">
                <h4 className="hidden"></h4>
                <script type="text/javascript"
                        src="//ad.hani.co.kr/RealMedia/ads/adstream_jx.ads/www.hani.co.kr/news@Right2?section=h21"></script>
            </section>

        )
    }
}
