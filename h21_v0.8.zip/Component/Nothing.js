export default function Nothing() {
    return (
        <div>
            <p>페이지가 없습니다.</p>
        </div>
    )
}